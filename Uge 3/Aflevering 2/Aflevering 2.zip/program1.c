

long p1(long x){

    return !(x > 0) ? x :  -x;

}